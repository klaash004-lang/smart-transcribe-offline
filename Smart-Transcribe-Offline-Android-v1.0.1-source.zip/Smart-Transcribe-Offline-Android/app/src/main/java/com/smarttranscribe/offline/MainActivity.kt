package com.smarttranscribe.offline

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import dev.ffmpegkit.whisper.Whisper
import dev.ffmpegkit.whisper.WhisperConfig
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val modelName = "ggml-base.bin"
    private val modelUrl = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin"
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var transcript: EditText
    private lateinit var chooseButton: Button
    private lateinit var runButton: Button
    private lateinit var exportButton: Button
    private var audioFile: File? = null
    private var lastSrt: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        updateModelStatus()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 28, 36, 32)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(0xFFF5F7FA.toInt())
        }
        fun heading(s: String, size: Float) = TextView(this).apply {
            text = s; textSize = size; setTextColor(0xFF142033.toInt())
            gravity = Gravity.RIGHT; setPadding(0, 12, 0, 12)
        }
        layout.addView(heading("SMART TRANSCRIBE", 25f))
        layout.addView(heading("التفريغ الصوتي العربي دون إنترنت", 17f))
        status = heading("جارٍ فحص نموذج التفريغ…", 14f)
        layout.addView(status)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; visibility = View.GONE
        }
        layout.addView(progress)
        chooseButton = Button(this).apply { text = "اختيار ملف صوتي"; setOnClickListener { pickAudio() } }
        layout.addView(chooseButton)
        runButton = Button(this).apply { text = "بدء التفريغ"; isEnabled = false; setOnClickListener { transcribe() } }
        layout.addView(runButton)
        layout.addView(heading("النص المستخرج (يمكنك تعديله)", 16f))
        transcript = EditText(this).apply {
            minLines = 10; gravity = Gravity.TOP or Gravity.RIGHT
            textDirection = View.TEXT_DIRECTION_RTL
            hint = "سيظهر النص هنا بعد انتهاء التفريغ"
            setTextSize(16f)
            setPadding(18, 18, 18, 18)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        layout.addView(transcript, LinearLayout.LayoutParams(-1, 0, 1f).apply { height = 620 })
        exportButton = Button(this).apply {
            text = "تصدير النص TXT"; isEnabled = false
            setOnClickListener { saveText(transcript.text.toString(), "transcript.txt", "text/plain") }
        }
        layout.addView(exportButton)
        val srtButton = Button(this).apply {
            text = "تصدير الترجمة SRT"; setOnClickListener {
                if (lastSrt.isBlank()) toast("لا توجد توقيتات بعد. نفّذ التفريغ أولاً.")
                else saveText(lastSrt, "transcript.srt", "application/x-subrip")
            }
        }
        layout.addView(srtButton)
        layout.addView(heading("ملاحظة: نزّل النموذج مرة واحدة (نحو 142 ميغابايت). بعد ذلك يعمل التفريغ محليًا دون إنترنت.", 12f))
        scroll.addView(layout)
        setContentView(scroll)
    }

    private fun modelFile() = File(filesDir, modelName)

    private fun updateModelStatus() {
        val ready = modelFile().exists() && modelFile().length() > 100_000_000L
        status.text = if (ready) "النموذج جاهز — يمكن التفريغ دون إنترنت" else "يلزم تنزيل نموذج العربية متعدد اللغات أول مرة"
        runButton.isEnabled = ready && audioFile != null
    }

    private fun pickAudio() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
        }
        startActivityForResult(i, 101)
    }

    @Deprecated("Use Activity Result APIs in production")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 102 && resultCode == RESULT_OK) {
            finishExport(data?.data)
            return
        }
        if (requestCode == 101 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            scope.launch {
                try {
                    audioFile = withContext(Dispatchers.IO) { copyUri(uri) }
                    status.text = "تم اختيار: ${audioFile?.name}"
                    runButton.isEnabled = modelFile().exists()
                    if (!modelFile().exists()) downloadModel()
                } catch (e: Exception) { toast("تعذر قراءة الملف: ${e.message}") }
            }
        }
    }

    private fun copyUri(uri: Uri): File {
        // whisper-android's bundled decoder supports WAV, MP3 and FLAC.
        // Keep a real extension so the native decoder can identify the format.
        val extension = when (contentResolver.getType(uri)?.lowercase(Locale.ROOT)) {
            "audio/wav", "audio/wave", "audio/x-wav" -> "wav"
            "audio/mpeg", "audio/mp3" -> "mp3"
            "audio/flac", "audio/x-flac" -> "flac"
            else -> throw IllegalArgumentException("الصيغ المدعومة حاليًا: WAV وMP3 وFLAC")
        }
        val out = File(cacheDir, "audio_${System.currentTimeMillis()}.$extension")
        contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "تعذر فتح الملف" }
            FileOutputStream(out).use { output -> input.copyTo(output) }
        }
        return out
    }

    private suspend fun downloadModel() = withContext(Dispatchers.IO) {
        try {
            withContext(Dispatchers.Main) {
                status.text = "تنزيل النموذج لأول مرة… لا تغلق التطبيق"
                progress.visibility = View.VISIBLE
                progress.isIndeterminate = true
                chooseButton.isEnabled = false
            }
            val temp = File(filesDir, "$modelName.part")
            val conn = (URL(modelUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 20000; readTimeout = 60000
                instanceFollowRedirects = true
            }
            conn.connect()
            if (conn.responseCode !in 200..299) throw IllegalStateException("HTTP ${conn.responseCode}")
            conn.inputStream.use { input -> FileOutputStream(temp).use { output -> input.copyTo(output) } }
            if (temp.length() < 100_000_000L) throw IllegalStateException("حجم النموذج غير مكتمل")
            if (!temp.renameTo(modelFile())) throw IllegalStateException("تعذر حفظ النموذج")
            withContext(Dispatchers.Main) {
                progress.visibility = View.GONE
                chooseButton.isEnabled = true
                status.text = "اكتمل تنزيل النموذج. أصبح التفريغ محليًا."
                updateModelStatus()
            }
        } catch (e: Exception) {
            withContext(Dispatchers.Main) {
                progress.visibility = View.GONE
                chooseButton.isEnabled = true
                status.text = "فشل تنزيل النموذج: ${e.message}. أعد المحاولة باختيار الملف مجددًا."
            }
        }
    }

    private fun transcribe() {
        val audio = audioFile ?: return
        runButton.isEnabled = false
        status.text = "جارٍ التفريغ على الهاتف… قد يستغرق وقتًا حسب طول التسجيل"
        scope.launch {
            var model: dev.ffmpegkit.whisper.WhisperModel? = null
            try {
                val result = withContext(Dispatchers.IO) {
                    model = Whisper.loadModel(this@MainActivity, modelFile().absolutePath)
                    Whisper.transcribe(model!!, audio.absolutePath, WhisperConfig(language = "ar"))
                }
                transcript.setText(result.text.trim())
                lastSrt = result.segments.mapIndexed { index, seg ->
                    "${index + 1}\n${srtTime(seg.startMs)} --> ${srtTime(seg.endMs)}\n${seg.text.trim()}\n"
                }.joinToString("\n")
                exportButton.isEnabled = true
                status.text = "اكتمل التفريغ محليًا — راجع الكلمات والأسماء قبل الاعتماد"
            } catch (e: Exception) {
                status.text = "تعذر التفريغ: ${e.message}"
            } finally {
                withContext(Dispatchers.IO) { model?.let { Whisper.releaseModel(it) } }
                runButton.isEnabled = true
            }
        }
    }

    private fun srtTime(ms: Long): String {
        val h = ms / 3_600_000
        val m = (ms % 3_600_000) / 60_000
        val s = (ms % 60_000) / 1_000
        val milli = ms % 1_000
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", h, m, s, milli)
    }

    private fun saveText(content: String, filename: String, mime: String) {
        if (content.isBlank()) { toast("لا يوجد نص للتصدير"); return }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = mime
            putExtra(Intent.EXTRA_TITLE, filename)
        }
        pendingExport = content
        startActivityForResult(intent, 102)
    }

    private var pendingExport: String = ""
    private fun finishExport(uri: Uri?) {
        if (uri == null) return
        try {
            contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8).use { it?.write(pendingExport) }
            toast("تم حفظ الملف")
        } catch (e: Exception) { toast("تعذر الحفظ: ${e.message}") }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
