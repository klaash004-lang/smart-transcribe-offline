package com.smarttranscribe.offline

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import dev.ffmpegkit.whisper.Whisper
import dev.ffmpegkit.whisper.WhisperConfig
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class MainActivity : Activity() {
    private data class ModelOption(
        val id: String,
        val title: String,
        val fileName: String,
        val url: String,
        val minimumBytes: Long,
        val description: String
    )

    private val modelOptions = listOf(
        ModelOption(
            id = "small",
            title = "Small — دقة أعلى (466 ميغابايت)",
            fileName = "ggml-small.bin",
            url = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small.bin",
            minimumBytes = 400_000_000L,
            description = "أعلى دقة من Base عادةً، لكنه أبطأ ويحتاج ذاكرة أكبر"
        ),
        ModelOption(
            id = "base",
            title = "Base — أسرع (142 ميغابايت)",
            fileName = "ggml-base.bin",
            url = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin",
            minimumBytes = 100_000_000L,
            description = "أسرع وأخف، لكن دقته أقل في العربية"
        )
    )

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val prefs by lazy { getSharedPreferences("transcribe", MODE_PRIVATE) }
    private var selectedModelId: String = "small"
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var transcript: EditText
    private lateinit var chooseButton: Button
    private lateinit var runButton: Button
    private lateinit var exportButton: Button
    private lateinit var modelSpinner: Spinner
    private var audioFile: File? = null
    private var lastSrt: String = ""
    private var pendingExport: String = ""

    private fun selectedModel() = modelOptions.first { it.id == selectedModelId }
    private fun modelFile(option: ModelOption = selectedModel()) = File(filesDir, option.fileName)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        selectedModelId = prefs.getString("model", "small") ?: "small"
        if (modelOptions.none { it.id == selectedModelId }) selectedModelId = "small"
        buildUi()
        updateModelStatus()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 28, 36, 32)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(0xFFF5F7FA.toInt())
        }
        fun heading(s: String, size: Float) = TextView(this).apply {
            text = s
            textSize = size
            setTextColor(0xFF142033.toInt())
            gravity = Gravity.RIGHT
            setPadding(0, 12, 0, 12)
        }

        layout.addView(heading("SMART TRANSCRIBE", 25f))
        layout.addView(heading("التفريغ الصوتي العربي دون إنترنت", 17f))
        layout.addView(heading("اختر التوازن أو الدقة الأعلى", 14f))

        modelSpinner = Spinner(this)
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            modelOptions.map { it.title }
        ).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        modelSpinner.adapter = adapter
        modelSpinner.setSelection(modelOptions.indexOfFirst { it.id == selectedModelId })
        modelSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val next = modelOptions[position].id
                if (next != selectedModelId) {
                    selectedModelId = next
                    prefs.edit().putString("model", next).apply()
                    updateModelStatus()
                    if (audioFile != null && !modelReady()) scope.launch { downloadModel() }
                }
            }
        }
        layout.addView(modelSpinner)

        status = heading("جارٍ فحص نموذج التفريغ…", 14f)
        layout.addView(status)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        layout.addView(progress)

        chooseButton = Button(this).apply {
            text = "اختيار ملف صوتي"
            setOnClickListener { pickAudio() }
        }
        layout.addView(chooseButton)

        runButton = Button(this).apply {
            text = "بدء التفريغ"
            isEnabled = false
            setOnClickListener { transcribe() }
        }
        layout.addView(runButton)

        layout.addView(heading("النص المستخرج (يمكنك تعديله)", 16f))
        transcript = EditText(this).apply {
            minLines = 10
            gravity = Gravity.TOP or Gravity.RIGHT
            textDirection = View.TEXT_DIRECTION_RTL
            hint = "سيظهر النص هنا بعد انتهاء التفريغ"
            setTextSize(16f)
            setPadding(18, 18, 18, 18)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        layout.addView(transcript, LinearLayout.LayoutParams(-1, 0, 1f).apply { height = 620 })

        exportButton = Button(this).apply {
            text = "تصدير النص TXT"
            isEnabled = false
            setOnClickListener { saveText(transcript.text.toString(), "transcript.txt", "text/plain") }
        }
        layout.addView(exportButton)

        val srtButton = Button(this).apply {
            text = "تصدير الترجمة SRT"
            setOnClickListener {
                if (lastSrt.isBlank()) toast("لا توجد توقيتات بعد. نفّذ التفريغ أولاً.")
                else saveText(lastSrt, "transcript.srt", "application/x-subrip")
            }
        }
        layout.addView(srtButton)

        layout.addView(heading(
            "معلومة: Small حجمه نحو 466 ميغابايت ويحتاج ذاكرة تشغيل أكبر (نحو 852 ميغابايت للمحرك). " +
                "اختر Base إذا أصبح الهاتف بطيئًا أو ظهرت رسالة نقص ذاكرة. بعد تنزيل النموذج يعمل دون إنترنت.",
            12f
        ))
        scroll.addView(layout)
        setContentView(scroll)
    }

    private fun modelReady(): Boolean {
        val option = selectedModel()
        return modelFile(option).exists() && modelFile(option).length() >= option.minimumBytes
    }

    private fun updateModelStatus() {
        val option = selectedModel()
        val ready = modelReady()
        status.text = if (ready) {
            "${option.title} جاهز — التفريغ يعمل دون إنترنت"
        } else {
            "النموذج ${option.id} غير محمّل. اختر ملفًا صوتيًا لتنزيله أول مرة."
        }
        runButton.isEnabled = ready && audioFile != null
    }

    private fun pickAudio() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
        }
        startActivityForResult(i, 101)
    }

    @Deprecated("Use Activity Result APIs in production")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 102 && resultCode == RESULT_OK) {
            finishExport(data?.data)
            return
        }
        if (requestCode == 101 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            scope.launch {
                try {
                    audioFile = withContext(Dispatchers.IO) { copyUri(uri) }
                    status.text = "تم اختيار الملف: ${audioFile?.name}"
                    if (!modelReady()) downloadModel() else updateModelStatus()
                } catch (e: Exception) {
                    toast("تعذر قراءة الملف: ${e.message}")
                }
            }
        }
    }

    private fun copyUri(uri: Uri): File {
        val extension = when (contentResolver.getType(uri)?.lowercase(Locale.ROOT)) {
            "audio/wav", "audio/wave", "audio/x-wav" -> "wav"
            "audio/mpeg", "audio/mp3" -> "mp3"
            "audio/flac", "audio/x-flac" -> "flac"
            else -> {
                val name = queryDisplayName(uri).orEmpty().lowercase(Locale.ROOT)
                when {
                    name.endsWith(".wav") -> "wav"
                    name.endsWith(".mp3") -> "mp3"
                    name.endsWith(".flac") -> "flac"
                    else -> throw IllegalArgumentException("الصيغ المدعومة حاليًا: WAV وMP3 وFLAC")
                }
            }
        }
        val out = File(cacheDir, "audio_${System.currentTimeMillis()}.$extension")
        contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "تعذر فتح الملف" }
            FileOutputStream(out).use { output -> input.copyTo(output) }
        }
        return out
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        } catch (_: Exception) { null }
    }

    private suspend fun downloadModel() = withContext(Dispatchers.IO) {
        val option = selectedModel()
        val target = modelFile(option)
        try {
            withContext(Dispatchers.Main) {
                status.text = "تنزيل ${option.title} لأول مرة… لا تغلق التطبيق"
                progress.visibility = View.VISIBLE
                progress.isIndeterminate = true
                progress.progress = 0
                chooseButton.isEnabled = false
                modelSpinner.isEnabled = false
                runButton.isEnabled = false
            }

            val temp = File(filesDir, "${option.fileName}.part")
            if (temp.exists()) temp.delete()
            val conn = (URL(option.url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 30000
                readTimeout = 180000
                instanceFollowRedirects = true
            }
            conn.connect()
            if (conn.responseCode !in 200..299) throw IllegalStateException("HTTP ${conn.responseCode}")
            val total = conn.contentLengthLong
            withContext(Dispatchers.Main) {
                progress.isIndeterminate = total <= 0
            }

            conn.inputStream.use { input ->
                FileOutputStream(temp).use { output ->
                    val buffer = ByteArray(128 * 1024)
                    var count: Int
                    var downloaded = 0L
                    var lastUiUpdate = 0L
                    while (input.read(buffer).also { count = it } != -1) {
                        output.write(buffer, 0, count)
                        downloaded += count
                        if (total > 0 && downloaded - lastUiUpdate >= 1024 * 1024) {
                            lastUiUpdate = downloaded
                            val percent = ((downloaded * 100) / total).toInt().coerceIn(0, 100)
                            withContext(Dispatchers.Main) {
                                progress.progress = percent
                                status.text = "تنزيل النموذج: $percent%"
                            }
                        }
                    }
                }
            }
            if (temp.length() < option.minimumBytes) {
                throw IllegalStateException("حجم النموذج غير مكتمل (${temp.length()} بايت)")
            }
            if (target.exists()) target.delete()
            if (!temp.renameTo(target)) throw IllegalStateException("تعذر حفظ النموذج")

            withContext(Dispatchers.Main) {
                progress.progress = 100
                progress.visibility = View.GONE
                chooseButton.isEnabled = true
                modelSpinner.isEnabled = true
                updateModelStatus()
                toast("اكتمل تنزيل النموذج ${option.id}")
            }
        } catch (e: Exception) {
            withContext(Dispatchers.Main) {
                progress.visibility = View.GONE
                chooseButton.isEnabled = true
                modelSpinner.isEnabled = true
                status.text = "فشل تنزيل النموذج: ${e.message}. تحقق من الإنترنت ثم اختر الملف مجددًا."
            }
        }
    }

    private fun transcribe() {
        val audio = audioFile ?: return
        if (!modelReady()) {
            toast("النموذج غير جاهز. اختر الملف الصوتي لتنزيله.")
            return
        }
        runButton.isEnabled = false
        modelSpinner.isEnabled = false
        status.text = "جارٍ التفريغ باستخدام ${selectedModel().id}… قد يستغرق وقتًا"
        scope.launch {
            var model: dev.ffmpegkit.whisper.WhisperModel? = null
            try {
                val result = withContext(Dispatchers.IO) {
                    model = Whisper.loadModel(this@MainActivity, modelFile().absolutePath)
                    Whisper.transcribe(model!!, audio.absolutePath, WhisperConfig(language = "ar"))
                }
                transcript.setText(result.text.trim())
                lastSrt = result.segments.mapIndexed { index, seg ->
                    "${index + 1}\n${srtTime(seg.startMs)} --> ${srtTime(seg.endMs)}\n${seg.text.trim()}\n"
                }.joinToString("\n")
                exportButton.isEnabled = true
                status.text = "اكتمل التفريغ باستخدام ${selectedModel().id} — راجع الأسماء والكلمات"
            } catch (e: OutOfMemoryError) {
                status.text = "ذاكرة الهاتف غير كافية لهذا النموذج. اختر Base ثم أعد المحاولة."
                toast("الذاكرة غير كافية. اختر نموذج Base.")
            } catch (e: Exception) {
                status.text = "تعذر التفريغ: ${e.message}"
            } finally {
                withContext(Dispatchers.IO) { model?.let { Whisper.releaseModel(it) } }
                modelSpinner.isEnabled = true
                runButton.isEnabled = modelReady() && audioFile != null
            }
        }
    }

    private fun srtTime(ms: Long): String {
        val h = ms / 3_600_000
        val m = (ms % 3_600_000) / 60_000
        val s = (ms % 60_000) / 1_000
        val milli = ms % 1_000
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", h, m, s, milli)
    }

    private fun saveText(content: String, filename: String, mime: String) {
        if (content.isBlank()) { toast("لا يوجد نص للتصدير"); return }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
            putExtra(Intent.EXTRA_TITLE, filename)
        }
        pendingExport = content
        startActivityForResult(intent, 102)
    }

    private fun finishExport(uri: Uri?) {
        if (uri == null) return
        try {
            contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8).use {
                it?.write(pendingExport)
            }
            toast("تم حفظ الملف")
        } catch (e: Exception) {
            toast("تعذر الحفظ: ${e.message}")
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
